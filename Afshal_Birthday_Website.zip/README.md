# Afshal Birthday Website ❤️

## Files
- index.html
- style.css
- script.js
- photo1.jpg ... photo5.jpg
- violin.mp3

## iPhone setup
1. Upload all files to one GitHub repository.
2. Rename your five photos exactly:
   photo1.jpg, photo2.jpg, photo3.jpg, photo4.jpg, photo5.jpg
3. Add your violin audio as `violin.mp3`.
4. In GitHub: Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.
5. GitHub will give you a free `github.io` link.

Note: iPhone browsers may block autoplay. The music starts after Afshal taps “Open Your Surprise”.
